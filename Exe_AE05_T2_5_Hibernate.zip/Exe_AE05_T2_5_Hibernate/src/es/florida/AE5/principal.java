package es.florida.AE5;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import org.hibernate.service.ServiceRegistry;

public class principal {
	/*
	 * Metode: mostrarPeliculas 
	 * Descripcio: llig tots el llibres y els mostra a traves del toString.
	 * Parametres d'entrada: sesio 
	 * Parametres d'exida: Ix el toString
	 */
	public static void mostrarLLibres(Session sesio) {
		sesio.beginTransaction();
		
		List listaLlibres = new ArrayList();
		listaLlibres = sesio.createQuery("FROM Llibre").list();
		for (Object obj : listaLlibres) {
			Llibre llib5 = (Llibre) obj;
			System.out.println(llib5.getTitol());
		}
		sesio.getTransaction().commit();
	}
	
	/*
	 * Metode: mostrarLlibre 
	 * Descripcio: Mostra el llibre que l'indiques.
	 * Parametres d'entrada: sesio 
	 * Parametres d'exida: Mostra el llibre indicat.
	 */

	public static void mostrarLlibre(Session sesio) {
		// Recuperar un objecte a partir del seu id

		System.out.println("Que llibre vols vore, introduix el id:");
		Scanner sc1 = new Scanner(System.in);
		int idVer = Integer.parseInt(sc1.nextLine());

		Llibre llib1 = (Llibre) sesio.get(Llibre.class, idVer);
		if (llib1 == null) {
			System.out.println("No hi ha pelicula amb la id:" + idVer);
		} else {
			System.out.println("Titol del llibre: " + llib1.getTitol() +"\n"+"El autor es: "+ llib1.getAutor() +"\n"+"El any de naixement es: "+ llib1.getAny_naixement()+"\n"+
					"El any de publicacio del llibre es: "+ llib1.getAny_publicacio()+"\n"+"La editorial del llibre es: "+ llib1.getEditorial()+"\n"+
					"El numero de pagines del llibre es: "+ llib1.getNombre_de_pagines());
		}
	}
	
	/*
	 * Metode: crearLlibre 
	 * Descripcio: Crea un llibre mes.
	 * Parametres d'entrada: sesio 
	 * Parametres d'exida: crea el llibre.
	 */

	public static void crearLlibre(Session sesio) {
		Scanner sc = new Scanner(System.in);
	
		System.out.print("�Vols crear un llibre de la biblioteca (s/n)? ");
		String respostaCrear = sc.nextLine();

		do {
			sesio.beginTransaction();
		// Crear nou objecte
		System.out.println("Anyadix el titol:");
		Scanner t = new Scanner(System.in);
		String titol = t.nextLine();
		System.out.println("Anyadix el autor:");
		Scanner a = new Scanner(System.in);
		String autor = t.nextLine();
		System.out.println("Anyadix el any de naixement del autor:");
		Scanner an = new Scanner(System.in);
		String anyNaixe = an.nextLine();
		System.out.println("Anyadix el any de publicacio del llibre:");
		Scanner ap = new Scanner(System.in);
		String anyPubli = ap.nextLine();
		System.out.println("Anyadix la editorial:");
		Scanner e = new Scanner(System.in);
		String editorial = t.nextLine();
		System.out.println("Anyadix el nombre de pagines del llibre:");
		Scanner np = new Scanner(System.in);
		int numeroPagines = Integer.parseInt(np.nextLine());

		Llibre llib = new Llibre(titol, autor, anyNaixe, anyPubli, editorial, numeroPagines);
		Serializable id = sesio.save(llib);
		System.out.println("Creat el llibre amb la id: " + id);

		sesio.getTransaction().commit();
		System.out.print("�Vols crear altre llibre en la biblioteca (s/n)? ");
		respostaCrear = sc.nextLine();

	} while (respostaCrear.equals("s"));

	}
	
	/*
	 * Metode: modificarLlibre 
	 * Descripcio: Modifica el llibre que l'indiques.
	 * Parametres d'entrada: sesio 
	 * Parametres d'exida: Modifica el llibre indicat.
	 */

	public static void modificarLlibre(Session sesio) {
		Scanner sc = new Scanner(System.in);

		// Modificar atributs d�un llibre a partir del seu id
		System.out.print("�Vols actualitzar un llibre de la biblioteca (s/n)? ");
		String respostaModificar = sc.nextLine();

		do {
			sesio.beginTransaction();
			System.out.print("Introdueix un id per a actualitzar les dades del llibre que correspon a eixe id: ");
			int idModificar = Integer.parseInt(sc.nextLine());
			Llibre llibreModificar = (Llibre) sesio.load(Llibre.class, idModificar);
			if (llibreModificar == null) {
				System.out.println("No hi ha ningun llibre amb id = " + idModificar);
			} else {
				System.out.print("Introdueix el titol: ");
				String modificarTitol = sc.nextLine();

				System.out.print("Introdueix el autor: ");
				String modificarAutor = sc.nextLine();

				System.out.print("Introdueix el any de naixement: ");
				String modificarAnyNaixement = sc.nextLine();

				System.out.print("Introdueix el any de publicacio: ");
				String modificarAnyPublicacio = sc.nextLine();

				System.out.print("Introdueix la editorial: ");
				String modificarEditorial = sc.nextLine();

				System.out.print("Introdueix el nombre de p�gines: ");
				int modificarNombrePagines = Integer.parseInt(sc.nextLine());

				llibreModificar.setTitol(modificarTitol);
				llibreModificar.setAutor(modificarAutor);
				llibreModificar.setAny_naixement(modificarAnyNaixement);
				llibreModificar.setAny_publicacio(modificarAnyPublicacio);
				llibreModificar.setEditorial(modificarEditorial);
				llibreModificar.setNombre_de_pagines(modificarNombrePagines);
				sesio.update(llibreModificar);
				System.out.println("s'han actualitzat les dades del llibre");

			}
			sesio.getTransaction().commit();
			System.out.print("�Vols modificar altre llibre de la biblioteca (s/n)? ");
			respostaModificar = sc.nextLine();

		} while (respostaModificar.equals("s"));

	}
	/*
	 * Metode: borrarLlibre 
	 * Descripcio: Borra el llibre que l'indiques.
	 * Parametres d'entrada: sesio 
	 * Parametres d'exida: Borra el llibre indicat.
	 */
	public static void borrarLlibre(Session sesio) {
		Scanner sc = new Scanner(System.in);

		// Borrar atributs d�un llibre a partir del seu id
		System.out.print("�Vols borrar un llibre de la biblioteca (s/n)? ");
		String respostaBorrar = sc.nextLine();

			do {
				sesio.beginTransaction();		
			System.out.println("Que llibre vols borrar, introduix el id:");
			
			int idBorrar = Integer.parseInt(sc.nextLine());
			Llibre llib3 = new Llibre();
			llib3.setId(idBorrar);
			sesio.delete(llib3);
	
			sesio.getTransaction().commit();
			System.out.print("�Vols borrar altre llibre de la biblioteca (s/n)? ");
			respostaBorrar = sc.nextLine();
	
		} while (respostaBorrar.equals("s"));
	}
	/*
	 * Metode: main 
	 * Descripcio: Cridem als metodes i els seleccionem amb un switch. Tambe carregem , creem i iniciem la sessio.
	 * Parametres d'entrada:  
	 * Parametres d'exida:
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Carrega la configuracio i crea una sessio factory
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
		configuration.addClass(Llibre.class);
		ServiceRegistry registry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
				.build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(registry);

		// Obri una nova sessi� de la session factory
		Session session = sessionFactory.openSession();


		boolean repe = true;
		while (repe) {

			repe = false;
			System.out.println("");
			// Ac� les operacio/ns CRUD (crear, llegir, actualitzar, borrar)
			System.out.println("1 per mostrar la llista de tots els llibres");
			System.out.println("2 per mostrar un llibre");
			System.out.println("3 per crear un llibre");
			System.out.println("4 per modificar un llibre");
			System.out.println("5 per borrar un llibre");

			Scanner scOpcio = new Scanner(System.in);
			int Opcio = Integer.parseInt(scOpcio.nextLine());

			switch (Opcio) {
			case 1:

				mostrarLLibres(session);
				System.out.println("vols tornar al menu? s/n");
				System.out.println("");
				Scanner sc1 = new Scanner(System.in);
				String scan1 = sc1.nextLine().toLowerCase();
				if (scan1.equals("s")) {
					repe = true;
				}
				break;
			case 2:

				mostrarLlibre(session);
				System.out.println("�vols tornar al menu? s/n");
				System.out.println("");
				Scanner sc2 = new Scanner(System.in);
				String scan2 = sc2.nextLine().toLowerCase();
				if (scan2.equals("s")) {
					repe = true;
				}

				break;
			case 3:

				crearLlibre(session);
				System.out.println("vols tornar al menu? s/n");
				System.out.println("");
				Scanner sc3 = new Scanner(System.in);
				String scan3 = sc3.nextLine().toLowerCase();
				if (scan3.equals("s")) {
					repe = true;
				}
				break;
			case 4:

				modificarLlibre(session);
				System.out.println("vols tornar al menu? s/n");
				System.out.println("");
				Scanner sc4 = new Scanner(System.in);
				String scan4 = sc4.nextLine().toLowerCase();
				if (scan4.equals("s")) {
					repe = true;
				}
				break;
			case 5:

				borrarLlibre(session);
				System.out.println("vols tornar al menu? s/n");
				System.out.println("");
				Scanner sc5 = new Scanner(System.in);
				String scan5 = sc5.nextLine().toLowerCase();
				if (scan5.equals("s")) {
					repe = true;
				}
				break;
			}
		
		}
		session.close();
		System.out.println("Commit de la transaccio i sesio tancada");

	}

}
